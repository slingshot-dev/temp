import RequestPage from "./requestPage";
import {ParsedUrlQueryInput} from "querystring";

export default class SearchFlux {
    editionType: string;
    editionName: string;
    fluxStatus: string;
    fluxSubmit: string;
    receptionDate: string;
    workspaceId: number;
    requestPage: RequestPage;


    constructor(editionType: string, editionName: string, fluxStatus : string, fluxSubmit: string, receptionDate: string, workspaceId: number, requestPage: RequestPage) {
        this.editionType = editionType;
        this.editionName = editionName;
        this.fluxStatus = fluxStatus;
        this.fluxSubmit = fluxSubmit;
        this.receptionDate = receptionDate;
        this.workspaceId = workspaceId;
        this.requestPage = requestPage;
    }

    objToJSON(): ParsedUrlQueryInput {
        return Object.assign({}, {
            type: this.editionType,
            name: this.editionName,
            fluxStatus: this.fluxStatus,
            fluxSubmit: this.fluxSubmit,
            receptionDate: this.receptionDate,
            workspaceId: this.workspaceId,
            page: this.requestPage.page,
            size: this.requestPage.size,
            sortField: this.requestPage.sortField,
            sortOrder: this.requestPage.sortOrder
        });
    }



    static fromJSON(json: ParsedUrlQueryInput): SearchFlux {
        let searchFlux = Object.create(SearchFlux.prototype);
        return Object.assign(searchFlux,  {
            workspaceId: json.workspaceId,
            editionType: json.type,
            editionName: json.name,
            fluxSubmit: json.fluxSubmit,
            fluxStatus: json.fluxStatus,
            receptionDate: json.receptionDate,
            requestPage: new RequestPage(Number(json.page), Number(json.size),
                String(json.sortField), String(json.sortOrder))
        });
    }
};

