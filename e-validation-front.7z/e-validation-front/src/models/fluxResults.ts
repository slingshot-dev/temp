import Flux from "./flux";

export default class FluxResults {
    elementDTOs : Flux[];
    numberElement: number;

    constructor(fluxDTOList : Flux[], numberElement : number) {
        this.elementDTOs = fluxDTOList;
        this.numberElement = numberElement;
    }
};
