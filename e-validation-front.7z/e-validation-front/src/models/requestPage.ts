import {ParsedUrlQueryInput} from "querystring";

export default class RequestPage {
    page: number;
    size: number;
    sortField: string;
    sortOrder: string;

    constructor(page: number, size: number, sortField: string, sortOrder: string) {
        this.page = page;
        this.size = size;
        this.sortField = sortField;
        this.sortOrder = sortOrder;
    }


}
