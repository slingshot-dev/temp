import RequestPage from "./requestPage";
import {ParsedUrlQueryInput} from "querystring";

export default class SearchDocuments {
    documentName: string;
    requestPage: RequestPage;

    constructor(documemntName: string, requestPage: RequestPage) {
        this.documentName = documemntName;
        this.requestPage = requestPage;
    }

    objToJSON(): ParsedUrlQueryInput {
        return Object.assign({}, {
            documentName: this.documentName,
            page: this.requestPage.page,
            size: this.requestPage.size,
            sortField: this.requestPage.sortField,
            sortOrder: this.requestPage.sortOrder
        });
    }



    static fromJSON(json: ParsedUrlQueryInput): SearchDocuments {
        let searchDocuments = Object.create(SearchDocuments.prototype);
        return Object.assign(searchDocuments,  {
            documentName: json.documentName,
            requestPage: new RequestPage(Number(json.page), Number(json.size),
                String(json.sortField), String(json.sortOrder))
        });
    }

};
