import Flux from "./flux";

export default class Document {
    id: number;
    name: string;
    metadataJson: string;
    user: string;
    flux: Flux;
    workspaceName: string;
    workspaceId: number;


    constructor(
        id: number,
        name: string,
        metadataJson: string,
        user: string,
        flux: Flux,
        workspaceName: string,
        workspaceId: number
    ) {
        this.id = id;
        this.name = name;
        this.metadataJson = metadataJson;
        this.user = user;
        this.flux = flux;
        this.workspaceName = workspaceName;
        this.workspaceId = workspaceId;

    }
};
