import Document from "./document";

export default class DocumentResults {
    elementDTOs : Document[];
    numberElement: number;

    constructor(documents : Document[], numberElement : number) {
        this.elementDTOs = documents;
        this.numberElement = numberElement;
    }
};
