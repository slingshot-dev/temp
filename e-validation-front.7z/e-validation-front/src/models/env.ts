export default class Env  {
    environment : string;


    constructor(environment: string) {
        this.environment = environment
    }

}
