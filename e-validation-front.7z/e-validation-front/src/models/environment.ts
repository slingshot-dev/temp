export default class Environment  {
    basename : string;
    urlApi: string;

    constructor(basename: string, urlApi: string) {
        this.basename = basename;
        this.urlApi = urlApi;
    }

}
