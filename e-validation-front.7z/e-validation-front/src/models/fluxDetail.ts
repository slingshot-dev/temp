export default class FluxDetail {
    type : string;
    name : string;
    modificationDate: string;
    user : string;
    projectName : string
    metadataJson : string;
    creationDate: string;
    documentNumber : number;


    constructor(type: string, name: string, modificationDate: string, user: string, projectName: string, metadataJson: string, creationDate: string, documentNumber: number) {
        this.type = type;
        this.name = name;
        this.modificationDate = modificationDate;
        this.user = user;
        this.projectName = projectName;
        this.metadataJson = metadataJson;
        this.creationDate = creationDate;
        this.documentNumber = documentNumber;
    }
};
