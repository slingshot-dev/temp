import Authority from "./authority";

export default class UserInfo {
    id: number;
    email: string;
    authorityList: Authority[];


    constructor(
        id: number,
        mail: string,
        authorityList: Authority[]
    ) {
        this.id = id;
        this.email = mail;
        this.authorityList = authorityList;
    }
};
