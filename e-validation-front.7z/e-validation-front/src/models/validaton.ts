export default class Validation {
    userId: number;
    fluxId: number;
    email: string;

    constructor(userId: number, fluxId: number, email: string) {
        this.userId = userId;
        this.fluxId = fluxId;
        this.email = email;
    }
};
