export default class Workspace {
    id: number;
    technicalId: number;
    name: string;

    constructor(
        id: number,
        technicalId: number,
        name: string
    ) {
        this.id = id;
        this.technicalId = technicalId;
        this.name = name;
    }
};
