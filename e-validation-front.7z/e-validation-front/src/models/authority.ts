export default class Authority {
    authority : string;

    constructor(authority: string) {
        this.authority = authority;
    }
}
