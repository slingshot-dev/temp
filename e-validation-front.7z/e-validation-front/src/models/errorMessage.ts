export default class ErrorMessage {
    hasErrors : boolean;
    description : string;
    title: string;
    icon: string

    constructor(hasErrors: boolean, description: string, title: string, icon : string ) {
        this.hasErrors = hasErrors;
        this.description = description;
        this.title = title;
        this.icon = icon;
    }
}
