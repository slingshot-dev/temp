export default class Flux {
    id: number;
    type: string;
    name: string;
    fluxStatus: string;
    fluxSubmit: boolean;
    creationDate: string;
    nbResult: number;
    role: string;
    workspaceName: string;


    constructor(id: number, type: string, name: string, fluxSubmit: boolean, creationDate: string, nbResult: number, fluxStatus: string,
                role: string, workspaceName: string) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.fluxSubmit = fluxSubmit;
        this.creationDate = creationDate;
        this.nbResult = nbResult;
        this.fluxStatus = fluxStatus;
        this.role = role;
        this.workspaceName = workspaceName;
    }
};
