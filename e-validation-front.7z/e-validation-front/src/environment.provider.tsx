import React, {createContext, FunctionComponent, useEffect, useState} from 'react';
import Environment from "./models/environment";
// @ts-ignore
import {Loader} from "@axa-fr/react-toolkit-all";

export const EnvironmentContext = createContext<Environment>(new Environment("", ""));

export const EnvironmentConsumer = EnvironmentContext.Consumer;

export function withEnvironment<T>(Component: FunctionComponent<T>) {
    return (props: T) => {
        return (
            <EnvironmentConsumer>
                {(store: Environment) => <Component {...props} {...store} />}
            </EnvironmentConsumer>
        )
    }
}

function getEnvironmentData() {
    return new Environment("", "http://localhost:9090/evalidation/{path}");
}

const EnvironmentProvider: FunctionComponent = ({children}) => {
    const [environment, setEnvironment] = useState<Environment>(new Environment("", ""));
    const [loading, setLoading] = useState<string>("get");

    useEffect(() => {
        setEnvironment( getEnvironmentData());
        setLoading("none");

    }, []);

    return (
        <>
            <Loader mode={loading} text="Loading...">
                <EnvironmentContext.Provider value={environment}>
                    {children}
                </EnvironmentContext.Provider>
            </Loader>

        </>
    );
};

export default EnvironmentProvider;
