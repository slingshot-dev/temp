import config from './evalidationConfig'

const configuration = {
    client_id: `${config.client_id}`,
    client_secret: `${config.client_secret}`,
    redirect_uri: `${config.redirect_uri}`,
    response_type: 'code',
    post_logout_redirect_uri: `config.post_logout_redirect_uri`,
    scope: 'urn:axa:france:evalidation-api-cst urn:axa:france:evalidation-api-write openid email profile',
    authority: `${config.authority}`,
    silent_redirect_uri: `${config.silent_redirect_uri}`,
    automaticSilentRenew: true,
    loadUserInfo: true
};

export default configuration;
