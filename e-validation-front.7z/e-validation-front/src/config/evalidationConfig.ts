import devConfig from './environment_dev.json'
import stageConfig from './environment.json'

const evalidatonConfig = process.env["REACT_APP_ENV"] == 'DEV' ? devConfig : stageConfig;
export default evalidatonConfig;
