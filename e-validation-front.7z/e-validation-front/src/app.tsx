import React, {FunctionComponent} from 'react';
// @ts-ignore
import {AuthenticationProvider, InMemoryWebStorage, oidcLog, withOidcSecure} from '@axa-fr/react-oidc-context';
import oidcConfiguration from './config/configuration';
import "./app.scss";

import EnvironmentProvider, {withEnvironment} from "./environment.provider";
import Home from "./pages/home";


const RouteWithEnvironment = withOidcSecure(withEnvironment(Home));

const App: FunctionComponent = () => {

    return (

        <>
            {/*
              // @ts-ignore */}
            <AuthenticationProvider
                configuration={oidcConfiguration}
                loggerLevel={oidcLog.DEBUG}
                isEnabled={true}
                UserStore={InMemoryWebStorage}
            >
                <EnvironmentProvider>
                    <RouteWithEnvironment/>
                </EnvironmentProvider>
            </AuthenticationProvider>
        </>
    );
};


export default App;

