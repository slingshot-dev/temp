import UserInfo from "../models/userInfo";
import configurationService from "./config-api";
import Authority from "../models/authority";
import Env from "../models/env";



export default class EnvService {

    static getEnvironement(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>): Promise<Env> {
        return fetch(`${configurationService.api_url}/environment`)
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text)
                    });
                }
                return response.json();
            })
            .catch(error => this.handleError(error));

    }

    static handleError(error: Error): void {
        console.error(error);
    }




}
