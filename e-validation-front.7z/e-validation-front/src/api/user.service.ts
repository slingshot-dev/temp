import UserInfo from "../models/userInfo";
import configurationService from "./config-api";
import Authority from "../models/authority";


export enum AuthoritiesEnum {
    LECTEUR,
    VALIDEUR ,
    MANAGER ,
    ADMINISTRATEUR
}

export default class UserService {


    static getUserByMail(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>): Promise<UserInfo> {
        return fetch(`${configurationService.api_url}/users/mail`)
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text)
                    });
                }
                return response.json();
            })
            .catch(error => this.handleError(error));

    }

    static handleError(error: Error): void {
        console.error(error);
    }


    static hasPrivilege(authorities: Authority[], role: AuthoritiesEnum) {

        const userAuthority : AuthoritiesEnum = (<any>AuthoritiesEnum)[authorities[0].authority];

        return userAuthority >= role;





    }

    static hasRole(authorities: Authority[], role: AuthoritiesEnum) {

        const userAuthority : AuthoritiesEnum = (<any>AuthoritiesEnum)[authorities[0].authority];

        return userAuthority == role;





    }

}
