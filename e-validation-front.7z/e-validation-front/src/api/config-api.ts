import evalidationConfig from '../config/evalidationConfig'

const configurationService = {
    api_url: evalidationConfig.api_url

};

export default configurationService;
