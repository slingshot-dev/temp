import Workspace from "../models/workspace";
// @ts-ignore
import UserInfo from "../models/userInfo";
import configurationService from "./config-api";


export default class WorkspaceService {

    static getWorkspaces(usr: number, fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>): Promise<Workspace[]> {
        return fetch(`${configurationService.api_url}/workspaces`)
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text)
                    });
                }
                return response.json();
            })
            .catch(error => this.handleError(error));

    }

    static handleError(error: Error): void {
        console.error(error);
    }

}
