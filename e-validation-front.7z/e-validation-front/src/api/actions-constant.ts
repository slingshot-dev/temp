export const VALIDATE : string = "VALIDATE";
export const INVALIDATE : string = "INVALIDATE";
export const SUBMIT : string = "SUBMIT";
