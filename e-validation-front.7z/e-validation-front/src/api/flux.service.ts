import SearchFlux from "../models/searchFlux";
import FluxResults from "../models/fluxResults";
import FluxDetail from "../models/fluxDetail";
import Validation from "../models/validaton";
import configurationService from "./config-api";
import * as queryString from "querystring";

export default class FluxService {

    static getFluxByWorkspace(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>, searchFlux: SearchFlux, workspaceId: number): Promise<FluxResults> {
        const searchString = queryString.stringify(searchFlux.objToJSON());

        return fetch(`${configurationService.api_url}/flux/workspaces/${workspaceId}?${searchString}`, {
            mode: "cors",
            method: 'GET',
            headers: {'Content-Type': 'application/json'}
        })
            .then(response => {
                    if (!response.ok) {
                        return response.text().then(text => {
                            throw new Error(text)
                        });
                    }
                    return response.json();
                }
            )


    }

    static getFluxById(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>, id: number): Promise<FluxDetail> {
        return fetch(`${configurationService.api_url}/flux/${id}`)
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text)
                    });
                }
                return response.json();
            })

    }

    static handleError(error: Error): void {
        console.error(error);
    }

    static validate(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>, validation: Validation): Promise<Response> {
        return fetch(`${configurationService.api_url}/flux/validate/${validation.fluxId}`, {
            mode: "cors",
            method: 'PUT',
            headers: {'Content-Type': 'application/json'}
        })


    }

    static invalidate(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>, validation: Validation): Promise<Response> {
        return fetch(`${configurationService.api_url}/flux/invalidate/${validation.fluxId}`, {
            mode: "cors",
            method: 'PUT',

            headers: {'Content-Type': 'application/json'}
        })
    }

    static submit(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>, validation: Validation): Promise<Response> {
        return fetch(`${configurationService.api_url}/flux/submit/${validation.fluxId}`, {
            mode: "cors",
            method: 'PUT',
            headers: {'Content-Type': 'application/json'}
        })


    }

    static isValidator(role: string): boolean {
        return role === 'VALIDEUR' || role === 'MANAGER' || role === 'ADMINISTRATEUR';

    };

}
