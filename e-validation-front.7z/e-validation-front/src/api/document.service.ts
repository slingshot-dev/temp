import SearchDocuments from "../models/searchDocuments";
import DocumentResults from "../models/documentResults";
import Document from "../models/document";
import configurationService from "./config-api";
import queryString from "querystring";

export default class DocumentService {

    static getDocumentsByFlux(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>, searchDocuments: SearchDocuments,
                              fluxId : string): Promise<DocumentResults> {
        const searchString = queryString.stringify(searchDocuments.objToJSON());

        return fetch(`${configurationService.api_url}/document/${fluxId}?${searchString}`, {
            mode: "cors",
            method: 'GET',
            headers: {'Content-Type': 'application/json'}
        })
            .then(response => {
                    if (!response.ok) {
                        return response.text().then(text => {
                            throw new Error(text)
                        });
                    }
                    return response.json();
                }
            )


    }

    static getDocumentById(fetch: (input: RequestInfo, init?: RequestInit) => Promise<Response>, id: number): Promise<Document> {
        return fetch(`${configurationService.api_url}/document/${id}/detail`)
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text)
                    });
                }
                return response.json();
            })

    }

    static handleError(error: Error): void {
        console.error(error);
    }

}
