import React, {FunctionComponent} from 'react';
import Documents from "../components/documents/documents";
import {RouteComponentProps} from "react-router-dom";
import * as QueryString from "querystring";
import SearchDocuments from "../models/searchDocuments";
import NavBarApp from "../components/nav-bar";
import UserInfo from "../models/userInfo";


type Params = {
    id: string
}

type Usr = {
    usr: UserInfo
}

const DocumentList: FunctionComponent<RouteComponentProps<Params> & Usr> = ({match, history, location, usr}) => {

    const search = location.search ? SearchDocuments.fromJSON(QueryString.parse(location.search.slice(1))) : null;
    const props = search ? {...search, ...{fluxId: match.params.id}} : {fluxId: match.params.id};


    return (
        <>
            <NavBarApp usr={usr} title={"Liste des documents"}/>
            <div className="af-home container">
                <Documents  {...props}/>
            </div>
        </>
    );
}

export default DocumentList;
