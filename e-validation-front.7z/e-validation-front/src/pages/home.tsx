import React, {FunctionComponent} from 'react';
// @ts-ignore
import HeaderApp from "../components/header/header";
import NavBarApp from "../components/nav-bar/nav-bar";
import {BrowserRouter as Router, Route, Switch} from "react-router-dom";
import WorkspaceList from "./workspace-list";
import DocumentList from "./document-list";
import PdfViewer from "./pdf-viewer";
import FooterApp from "../components/footer/footer";


import "../app.scss";
// @ts-ignore
import {UserContextProvider} from "../components/user-provider";
import {UserContext} from '../components/user-provider/user.provider';
import UserInfo from "../models/userInfo";
import NotFound from "../components/not-found";
import ScrollToTop from "./scrollToTop";

const Home: FunctionComponent = () => {
    return (
        <>
            <UserContextProvider>
                <UserContext.Consumer>
                    {(usr : UserInfo) => {
                        if (usr.id <= 0) {
                            return <div></div>
                        }
                        return (

                            <Router>
                                <HeaderApp usr={usr}/>
                                <ScrollToTop />
                                <Switch>
                                    <Route exact path="/"
                                           render={(props) => <WorkspaceList {...props} usr={usr}/>}/>
                                    <Route path="/workspaces/:id"
                                           render={(props) => <WorkspaceList {...props} usr={usr} />}/>
                                    <Route path="/open/:id"
                                           render={(props) => <DocumentList {...props} usr={usr} />}/>


                                    <Route exact path="/view/:id" component={PdfViewer}/>
                                    <Route component={NotFound} />
                                </Switch>
                                <FooterApp/>


                            </Router>
                        );
                    }}
                </UserContext.Consumer>
            </UserContextProvider>
        </>
    );
}


export default Home;
