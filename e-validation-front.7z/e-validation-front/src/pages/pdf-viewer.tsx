import React, {FunctionComponent} from 'react';
import {RouteComponentProps} from "react-router-dom";
import FileViewerApp from "../components/file-viewer/file-viewer";


type Params = {
    id: string
}

const PdfViewer: FunctionComponent<RouteComponentProps<Params>> = ({match}) => {
    return (

        <div className="af-home container">
            <FileViewerApp idDoc={match.params.id}/>
        </div>
    );
}

export default PdfViewer;
