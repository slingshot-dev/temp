import React, {FunctionComponent} from 'react';
import Workspaces from "../components/workspaces/workspaces";
// @ts-ignore
import UserInfo from "../models/userInfo";
import {RouteComponentProps} from "react-router-dom";
import NavBarApp from "../components/nav-bar";

type Params = {
    id: string
}

type Usr = {
    usr: UserInfo
}


const WorkspaceList: FunctionComponent<RouteComponentProps<Params> & Usr> = ({match, usr}, ) => {
    let  propsW = {...usr, ...{idWorkspace:match.params.id}};
    return (

        <>
            <NavBarApp usr={usr} title={"Validation des flux"}/>
            <Workspaces {...propsW}/>
        </>
    );
}


export default WorkspaceList;
