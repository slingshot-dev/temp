import React, {FunctionComponent} from "react";
// @ts-ignore
import './user-profile.scss';
// @ts-ignore
import {User} from "@axa-fr/react-toolkit-all";

// @ts-ignore


const UserProfile: FunctionComponent<UserInfo> = (usr) => {
    return (
        <>
            <User name={usr.usr.mail} href="#" profile={""}
                  onClick={() => {
                  }}/>
        </>
    )

};


export default UserProfile;
