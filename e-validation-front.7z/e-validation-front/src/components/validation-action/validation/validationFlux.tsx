import React, {FunctionComponent, useEffect, useState} from 'react';
import "./validationFlux.scss";
import FluxService from "../../../api/flux.service";
import Validation from "../../../models/validaton";
// @ts-ignore
import {withAuthentication} from '@axa-fr/react-oidc-context-fetch';
import {compose} from "recompose";
import {INVALIDATE, SUBMIT, VALIDATE} from "../../../api/actions-constant";
import ErrorMessage from "../../../models/errorMessage";
import errorIcon from "../../../assets/svg/error.svg";

type Props = {
    idFlux?: number,
    action?: string,
    role: string,
    submitAction?: string,
    childAction?: (idFlux: number, action: string, error: ErrorMessage) => void,
    handleStartChildAction?: () => void,
    fetch?: (input: RequestInfo, init?: RequestInit) => Promise<Response>

};


const ValidationFlux: FunctionComponent<Props> = ({idFlux = 0, submitAction = "", action = "", childAction, handleStartChildAction, fetch, role}) => {
    const [state, setState] = useState<string>(action);

    useEffect(() => {
        setState(action)
    }, [action]);

    const validate = (validation: Validation) => {
        if (handleStartChildAction) handleStartChildAction();
        if (submitAction !== SUBMIT) {

            FluxService.validate(typeof (fetch) === 'undefined' ? window.fetch : fetch, validation).then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text)
                    });
                }
                setState(VALIDATE);
                const errorMessage = new ErrorMessage(false, "", "", "")
                if (childAction) childAction(idFlux, VALIDATE, errorMessage)
            }).catch(
                error => {
                    let message = JSON.parse(error.message);
                    const errorMessage = new ErrorMessage(true, message.message, "Erreur lors de la validation", errorIcon);
                    if (childAction) childAction(idFlux, VALIDATE, errorMessage);
                }

            );
        }
    };

    const validateFlux = (idFlux: number, userId: number, action: string) => {
        if ((!action || action === INVALIDATE) && FluxService.isValidator(role)) {
            let validation = new Validation(userId, idFlux, "");
            validate(validation);
        }

    };

    return (
        <a className={(submitAction === SUBMIT || state === VALIDATE || !FluxService.isValidator(role)) ? "af-btn--circle two" : "af-btn--circle one"}
           onClick={(e) => {
               validateFlux(idFlux, 2, state)
           }} title="Valider" role="button">
            <i className="glyphicon glyphicon-thumbs-up"/>
        </a>
    )


};

const enhanceAuth = compose<Props, Props>(
    withAuthentication(fetch)
);

const ValidationFluxEnhance = enhanceAuth(ValidationFlux);

export default ValidationFluxEnhance;
