import React, {FunctionComponent, useEffect, useState} from 'react';
import "./submission.scss";
import Validation from "../../../models/validaton";
import FluxService from "../../../api/flux.service";
// @ts-ignore
import {withAuthentication} from '@axa-fr/react-oidc-context-fetch';
import {compose} from "recompose";
import {INVALIDATE, SUBMIT, VALIDATE} from "../../../api/actions-constant";
import ErrorMessage from "../../../models/errorMessage";
import errorIcon from "../../../assets/svg/error.svg";

type Props = {
    idFlux?: number,
    action?: string,
    role: string,
    submitAction?: string,
    childAction?: (idFlux: number, action: string, error: ErrorMessage) => void,
    handleStartChildAction?: () => void,
    fetch?: (input: RequestInfo, init?: RequestInit) => Promise<Response>
};


const Submission: FunctionComponent<Props> = ({idFlux = 0, action = "", submitAction, childAction, handleStartChildAction, fetch, role}) => {
    const [state, setState] = useState<string>(action);


    useEffect(() => {
        setState(action)
    }, [action]);

    const submit = (validation: Validation) => {
        if (handleStartChildAction) handleStartChildAction();
        if (submitAction !== SUBMIT) {
            FluxService.submit(typeof (fetch) === 'undefined' ? window.fetch : fetch, validation).then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text)
                    });
                }
                setState(SUBMIT);
                const errorMessage = new ErrorMessage(false, "", "", errorIcon)
                if (childAction) childAction(idFlux, SUBMIT, errorMessage)
            }).catch(error => {
                let message = JSON.parse(error.message);
                const errorMessage = new ErrorMessage(true, message.message, "Erreur lors de la soumission", errorIcon);
                if (childAction) childAction(idFlux, SUBMIT, errorMessage);
            });
        }
    };

    const submitFlux = (idFlux: number, userId: number, action: string) => {
        if ((action === INVALIDATE || action === VALIDATE) && FluxService.isValidator(role)) {
            let validation = new Validation(userId, idFlux, "");
            submit(validation);
        }

    };

    return (
        <a className={(submitAction === SUBMIT || (action !== INVALIDATE && action !== VALIDATE)) || !FluxService.isValidator(role) ? "af-btn--circle two" : "af-btn--circle one"}
           onClick={(e) => {
               submitFlux(idFlux, 2, state)
           }} title="Soumettre" role="button">
            <i className="glyphicon glyphicon-arrowthin-right"/>
        </a>
    )


};

const enhanceAuth = compose<Props, Props>(
    withAuthentication(fetch)
);

const SubmissionEnhance = enhanceAuth(Submission);

export default SubmissionEnhance;
