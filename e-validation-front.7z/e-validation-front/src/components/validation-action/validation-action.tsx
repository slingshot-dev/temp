import React, {FunctionComponent} from 'react';
import "./validation-action.scss";
import Invalidation from "./invalidation/invalidation";
import Submission from "./submission/submission";
import Validation from "./validation/validationFlux";
import ErrorMessage from "../../models/errorMessage";

type Props = {
    idFlux: number,
    action: string,
    submitAction: string,
    role: string,
    childAction?: (idFlux: number, action: string, error: ErrorMessage) => void,
    handleStartChildAction?: () => void
}

const ValidationAction: FunctionComponent<Props> = ({idFlux, action = "", submitAction = "",
                                                        childAction, handleStartChildAction,
                                                        role}) => {

    return (
        <>
            <Validation action={action} submitAction={submitAction} idFlux={idFlux} childAction={childAction}
                        handleStartChildAction={handleStartChildAction} role={role}/>
            <Invalidation action={action} submitAction={submitAction} idFlux={idFlux} childAction={childAction}
                          handleStartChildAction={handleStartChildAction} role={role}/>
            <Submission action={action} submitAction={submitAction} idFlux={idFlux} childAction={childAction}
                        handleStartChildAction={handleStartChildAction} role={role}/>
        </>
    )
};


export default ValidationAction;
