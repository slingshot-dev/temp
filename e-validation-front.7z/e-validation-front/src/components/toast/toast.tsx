import React, {FunctionComponent, useEffect, useState} from 'react';

import "./toast.scss";
import ErrorMessage from '../../models/errorMessage';


type ToastProps = {
    errorMessage: ErrorMessage,
    position: string
    autoDelete: boolean,
    dismissTime: number
};


const Toast: FunctionComponent<ToastProps> = (toastProp: ToastProps) => {

    const [errorMessage, setErrorMessage] = useState(toastProp.errorMessage);


    useEffect(() => {
        setErrorMessage(toastProp.errorMessage)
        setTimeout(() => {
            if (toastProp.errorMessage.hasErrors && toastProp.autoDelete) {
                setErrorMessage(new ErrorMessage(false, ", ", "", ""));
            }
        }, toastProp.dismissTime);

        // eslint-disable-next-line
    }, [toastProp.errorMessage]);



    const deleteToast = () => {
        setErrorMessage(new ErrorMessage(false, "", "", ""));
    }


    return (
        <>{
            errorMessage.hasErrors ? (
                <div className={`notification-container ${toastProp.position}`}>

                    <div

                        className={`notification toast ${toastProp.position}`}
                        style={{backgroundColor: '#d9534f'}}
                    >
                        <button onClick={() => deleteToast()}>
                            X
                        </button>
                        <div className="notification-image">
                            <img src={toastProp.errorMessage.icon} alt=""/>
                        </div>
                        <div>
                            <p className="notification-title">{toastProp.errorMessage.title}</p>
                            <p className="notification-message">
                                {toastProp.errorMessage.description}
                            </p>
                        </div>
                    </div>

                </div>
            ) : ""
        }


        </>
    )
};


export default Toast;
