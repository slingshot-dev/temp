import React, {FunctionComponent, useState} from 'react';
// @ts-ignore
import {NavBar, NavBarItem, Title} from '@axa-fr/react-toolkit-layout-header';
// @ts-ignore
import './nav-bar.scss';
import UserInfo from "../../models/userInfo";
import UserService, {AuthoritiesEnum} from "../../api/user.service";

type Usr = {
    usr: UserInfo,
    title: string
}

const NavBarApp: FunctionComponent<Usr> = (usr) => {

    const [visible, setVisible] = useState<boolean>(false);

    const handleClick  = () => {
        const { body } = document;
        body.classList.toggle('af-menu-open');
        const visibleTmp = !visible
        setVisible(visibleTmp);

    }

    return (
        <>
        <NavBar isVisible={visible} onClick={handleClick}>
            <NavBarItem
                className="af-nav__item--haschild af-nav__item"

                actionElt={<span className="af-nav__link">Gestion des flux</span>}
            />

            {UserService.hasPrivilege(usr.usr.authorityList, AuthoritiesEnum.MANAGER) ? (
                <NavBarItem
                    className="af-nav__item--haschild af-nav__item"

                    actionElt={<span className="af-nav__link one">Configuration</span>}
                >
                    <NavBarItem
                        key="table-1"
                        actionElt={
                            <a className="af-nav__link two" href="/notifications">
                                Notifications
                            </a>
                        }
                    />
                    {UserService.hasPrivilege(usr.usr.authorityList, AuthoritiesEnum.ADMINISTRATEUR) ? (
                        <NavBarItem
                            key="table-1"
                            actionElt={
                                <a className="af-nav__link two" href="/workspaces">
                                    Workspaces
                                </a>
                            }
                        />
                    ) : (
                        <></>
                    )}
                    <NavBarItem
                        key="table-1"
                        actionElt={
                            <a className="af-nav__link two" href="/projets">
                                Projets
                            </a>
                        }
                    />
                    <NavBarItem
                        key="table-1"
                        actionElt={
                            <a className="af-nav__link two" href="/utilisateurs">
                                Utilisateurs
                            </a>
                        }
                    />
                </NavBarItem>
            ) : null}
            {UserService.hasRole(usr.usr.authorityList, AuthoritiesEnum.LECTEUR) ? (
                <NavBarItem
                    className="af-nav__item--haschild af-nav__item"

                    actionElt={<span className="af-nav__link one">Notifications</span>}
                >
                    <NavBarItem
                        key="table-1"
                        actionElt={
                            <a className="af-nav__link two" href="/notifications">
                                Gestion des notifications
                            </a>
                        }
                    />
                </NavBarItem>
            ) : null}
        </NavBar>
            <Title title={usr.title} toggleMenu={handleClick} />
       </>


    )
};

export default NavBarApp;
