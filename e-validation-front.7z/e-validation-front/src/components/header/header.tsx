import React, {FunctionComponent, useEffect, useState} from "react";
import logo from "@axa-fr/react-toolkit-core/dist/assets/logo-axa.svg";
// @ts-ignore
import {Header, Name} from "@axa-fr/react-toolkit-all";
// @ts-ignore
import "./header.scss";
import UserProfile from "../user-profile/user-profile";
import UserInfo from "../../models/userInfo";
import {compose} from "recompose";
import {withAuthentication} from "@axa-fr/react-oidc-context-fetch/dist";
import EnvService from "../../api/env.service";

type Usr = {
    usr: UserInfo
}

type Props = {
    usr: UserInfo
    fetch?: (input: RequestInfo, init?: RequestInit) => Promise<Response>,
}

const HeaderApp: FunctionComponent<Usr> = (props: Props) => {

    const [env, setEnv] = useState("");

    useEffect(() => {
            let isCancelled = false;
            if (!isCancelled) {
                EnvService.getEnvironement(typeof (props.fetch) === 'undefined' ? window.fetch : props.fetch).then(f => {
                    setEnv(f.environment);

                });

            }
            return () => {
                isCancelled = true;
            };
        }, []
    )
    return (


        <Header>

            <>
                <Name
                    title="eValidation"
                    subtitle={env}
                    img={logo}
                    alt="Evalidation"
                    onClick={() => {
                    }}
                />

                <UserProfile usr={props.usr}/>

            </>

        </Header>
    );
}

const enhanceAuth = compose<Props, Props>(
    withAuthentication(fetch)
);

const HeaderEnhance = enhanceAuth(HeaderApp);

export default HeaderEnhance;
