import React, {FunctionComponent} from 'react';
import "./refresh.scss";


type Props = {
    buttonAction?: () => void
}

const Refresh: FunctionComponent<Props> = ({buttonAction}) => {

    return (

            <div className="refresh">
                <button type="button" className="btn btn-info btn-sm refresh-button" onClick={buttonAction}>
                    <span className="glyphicon glyphicon-refresh icon-refresh"/> Rafraîchir
                </button>
            </div>
    )
};


export default Refresh;
