import React, {FunctionComponent, useEffect, useState} from "react";
import './document-detail.scss';
import Document from "../../models/document";
import Flux from "../../models/flux";
import DocumentService from "../../api/document.service";
// @ts-ignore
import {withAuthentication} from '@axa-fr/react-oidc-context-fetch';
import {compose} from "recompose";
import ErrorMessage from "../../models/errorMessage";
import errorIcon from "../../assets/svg/error.svg";
import Toast from "../toast";

type Props = {
    idDocument: number,
    isPaneOpen: boolean,
    fetch?: (input: RequestInfo, init?: RequestInit) => Promise<Response>

}


const DocumentDetail: FunctionComponent<Props> = ({idDocument, isPaneOpen, fetch}) => {

    const [documentDetail, setDocumentDetail] = useState<Document>(new Document(0, "", "", "",
        new Flux(0, "", "", false, "", 0, "", "", ""), "", 0));

    const [metadata, setMetadata] = useState<string>("");
    const [errorMessage, setErrorMessage] = useState(new ErrorMessage(false, "", "", errorIcon))

    useEffect(() => {
            let isCancelled = false
            if (isPaneOpen && !isCancelled) {
                DocumentService.getDocumentById(typeof (fetch) === 'undefined' ? window.fetch : fetch, idDocument)
                    .then(f => {
                        setDocumentDetail(f);
                        setMetadata(JSON.parse(f.metadataJson));


                    })
                    .catch(error => {
                        let message = JSON.parse(error.message);
                        setErrorMessage(new ErrorMessage(true, message.message.substring(0, 300) + "...", "Détail du document", errorIcon));
                    })

                return () => {
                    isCancelled = true;
                };

            }
        }, [isPaneOpen, idDocument]
    );

    return (
        <>
            {
                errorMessage.hasErrors ?
                    <Toast
                        errorMessage={errorMessage}
                        position={'bottom-right'}
                        autoDelete={true}
                        dismissTime={10000}
                    />
                    : ""
            }

            <dl className="information-list">
               

                {
                    metadata && Object.keys(metadata).map((e, i) => (
                        <>
                            <dt>{e}</dt>
                            <dd>{Object.values(metadata)[i]}</dd>
                        </>
                    ))
                }

            </dl>
        </>
    );
};


const enhanceAuth = compose<Props, Props>(
    withAuthentication(fetch)
);

const DocumentDetailEnhance = enhanceAuth(DocumentDetail);

export default DocumentDetailEnhance;
