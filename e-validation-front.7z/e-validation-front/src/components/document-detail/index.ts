export { default } from './document-detail';
