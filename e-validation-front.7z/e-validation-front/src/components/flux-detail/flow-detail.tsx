import React, {FunctionComponent, useEffect, useState} from "react";
import FluxService from "../../api/flux.service";
import FluxDetail from "../../models/fluxDetail";
import './flow-detail.scss';
// @ts-ignore
import {withAuthentication} from '@axa-fr/react-oidc-context-fetch';
import {compose} from "recompose";
import ErrorMessage from "../../models/errorMessage";
import errorIcon from "../../assets/svg/error.svg";
import Toast from "../toast";

type Props = {
    idFlux: number,
    isPaneOpen: boolean,
    fetch?: (input: RequestInfo, init?: RequestInit) => Promise<Response>
}


const FlowDetail: FunctionComponent<Props> = ({idFlux, isPaneOpen, fetch}) => {

    const [fluxDetail, setFluxDetail] = useState<FluxDetail>(new FluxDetail("", "", "",
        "", "", "", "", 0));

    const [metadata, setMetadata] = useState<string>("");
    const [errorMessage, setErrorMessage] = useState(new ErrorMessage(false, "", "", errorIcon))

    useEffect(() => {
            if (isPaneOpen) {
                FluxService.getFluxById(typeof (fetch) === 'undefined' ? window.fetch : fetch, idFlux).then(f => {
                    setFluxDetail(f);
                    setMetadata(JSON.parse(f.metadataJson));
                }).catch(error => {
                        let message = JSON.parse(error.message);
                        setErrorMessage(new ErrorMessage(true, message.message.substring(0, 300) + "...", "Détail du flux", errorIcon));
                    }
                );
            }
        }, [isPaneOpen, idFlux]
    );

    return (
        <>
            {
                errorMessage.hasErrors ?
                    <Toast
                        errorMessage={errorMessage}
                        position={'bottom-right'}
                        autoDelete={true}
                        dismissTime={10000}
                    />
                    : ""
            }

            <dl className="information-list">
                {
                    metadata && Object.keys(metadata).map((e, i) => (
                        <>
                            <dt>{e}</dt>
                            <dd>{Object.values(metadata)[i]}</dd>
                        </>
                    ))
                }



            </dl>
        </>
    );
};

const enhanceAuth = compose<Props, Props>(
    withAuthentication(fetch)
);

const FlowDetailEnhance = enhanceAuth(FlowDetail);

export default FlowDetailEnhance;

