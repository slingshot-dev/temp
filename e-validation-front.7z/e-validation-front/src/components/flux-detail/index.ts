export { default } from './flow-detail';
