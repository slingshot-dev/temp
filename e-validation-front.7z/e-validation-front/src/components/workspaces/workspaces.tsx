import React, {FunctionComponent, useEffect, useReducer} from 'react';
// @ts-ignore
import {SelectInput} from "@axa-fr/react-toolkit-form-input-select";
import Title from "@axa-fr/react-toolkit-title";
import WorkspaceService from "../../api/workspace.service";
// @ts-ignore
import Loader from "@axa-fr/react-toolkit-loader";
// @ts-ignore
import {withAuthentication} from '@axa-fr/react-oidc-context-fetch';
import "./workspaces.scss";
import FlowList from "../flux/flow-list";
import {Route, useHistory} from "react-router-dom";
import InfoBar from "../info-bar/info-bar";
import {initialState, workpaceReducer} from "./workspace.reducer";
import {compose} from "recompose";
import Workspace from "../../models/workspace";
import RequestPage from "../../models/requestPage";
import SearchFlux from "../../models/searchFlux";
import * as queryString from "querystring";
import PropTypes from "prop-types";

export type IFetch = {
    fetch?: (input: RequestInfo, init?: RequestInit) => Promise<Response>,
    id: number,
    email: string,
    idWorkspace?: string;
}


const Workspaces: FunctionComponent<IFetch> = ({id, email, fetch, idWorkspace}) => {
    const [state, dispatch] = useReducer(workpaceReducer, {...initialState});
    if (idWorkspace) {
        state.currentWorkspace = "" + idWorkspace;
    }
    const {loaderMode, currentWorkspace, workspaceList, labelWorkspace} = state;
    const history = useHistory();

    useEffect(() => {
        let isCancelled = false;

        WorkspaceService.getWorkspaces(id, typeof (fetch) === 'undefined' ? window.fetch : fetch).then((w: any) => {
            if (!isCancelled) {
                dispatch({type: "ON_LOAD_WORKSPACE", workspaces: w});
                if (typeof (idWorkspace) !== "undefined") {
                    let id = typeof (idWorkspace) !== "undefined" ? +idWorkspace : 0;
                    let workspaces: Workspace[] = w.filter((e: any) => e.id === +id);
                    dispatch({type: "ON_CHANGE_WORKSPACE", curentWorkspace: "" + idWorkspace, labelWorkspace: workspaces[0].name});
                }
            }
        });
        return () => {
            isCancelled = true;
        };

    }, [id]);

    function getWorkspaceOptions() {
        let options: any = [];
        workspaceList.map(function (workspace) {
            options.push({
                value: workspace.id,
                label: workspace.name
            })
        });

        return options;
    }

    const handleSelectChange = (e: any) => {
        const pageParam = new RequestPage(0, 10, "", "desc");
        const initialSearchFlux = new SearchFlux( "", "", "", "", "", +e.value ,pageParam);
        const stringifield = queryString.stringify(initialSearchFlux.objToJSON());
        history.push({
            pathname: `/workspaces/${e.value}/flow-list`,
            search: stringifield
        })

    };

    return (
        <>
            <Loader mode={loaderMode}>


                {workspaceList.length > 0 ?
                    <div className="af-home container">

                        <div>
                            <div style={{marginBottom: "1.5rem"}}>
                                <Title>Choisir un workspace</Title>
                            </div>
                            <h5 style={{color: "#c91432", fontStyle: "italic", fontFamily: "HelveticaBoldCn"}}>
                                Champs obligatoires *
                            </h5>
                            <div className="table">

                                <div className="table-cell-workspace">
                                    <SelectInput
                                        name="Workspace"
                                        label="Workspace"
                                        onChange={(e: any) => handleSelectChange(e)}
                                        options={getWorkspaceOptions()}
                                        placeholder="- Sélectionner -"
                                        className = "select select-form__group"
                                        value={currentWorkspace != null ? currentWorkspace : ""}
                                    />
                                </div>
                            </div>
                        </div>


                    </div> :
                    <div></div>
                }
                {
                    currentWorkspace !== "" ?
                        <Route path="/workspaces/:id/flow-list"
                               render={(props) => <FlowList {...props} fetch={fetch}/>}/>

                        : <InfoBar/>
                }
            </Loader>
        </>
    );
};

const enhanceAuth = compose<IFetch, {}>(
    withAuthentication(fetch)
);

const WorkspacesEnhance = enhanceAuth(Workspaces);

export default WorkspacesEnhance;
