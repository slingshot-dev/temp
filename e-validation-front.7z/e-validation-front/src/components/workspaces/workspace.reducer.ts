import workspace from "../../models/workspace";
import Workspace from "../../models/workspace";

type Action =
    | { type: 'ON_LOAD_WORKSPACE', workspaces: workspace[] }
    | { type: 'ON_CHANGE_WORKSPACE', curentWorkspace: string, labelWorkspace : string; };

interface State  {
    loaderMode: string;
    currentWorkspace : string;
    workspaceList: Workspace[];
    labelWorkspace: string;
}

export const initialState : State = {
    loaderMode: "get",
    currentWorkspace :  "" ,
    workspaceList: [],
    labelWorkspace: ""
};

export const workpaceReducer = (state: State, action : Action) => {

    switch (action.type) {
        case "ON_LOAD_WORKSPACE":
            return {...state, workspaceList: action.workspaces, loaderMode: "none"};
        case "ON_CHANGE_WORKSPACE":
            return {...state, currentWorkspace: action.curentWorkspace, labelWorkspace: action.labelWorkspace, loaderMode: "none"};
        default: return {...state};

    }
};
