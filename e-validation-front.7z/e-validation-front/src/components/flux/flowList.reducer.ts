import Flux from "../../models/flux";

type Action =
    | { type: 'ON_LOAD_FLUX', fluxList: Flux[], totalResults: number, currentPage: number }
    // | { type: 'ON_FILTER_FLUX', searchFlux: SearchFlux }
    | { type: 'ON_CHANGE_SEARCH_TEXT_NAME', name: string }
    | { type: 'ON_CHANGE_SEARCH_TEXT_TYPE', typeIn: string }
    | { type: 'ON_CHANGE_SUBMIT', submit: string }
    | { type: 'ON_CHANGE_STATUS', status: string }
    | { type: 'ON_CHANGE_DATE', creationDate: string | null }
    | { type: 'ON_VALIDATION', fluxList: Flux[] }
    | { type: 'ON_DISPLAY_DETAIL', idFlux: number, isPaneOpen: boolean }
    | { type: 'ON_SEARCH' }
    | { type: 'ON_VALIDATION_CALL' };

interface State {
    loaderMode: string;
    name: string;
    type: string;
    status: string;
    submit: string;
    dateCreation: string | null;
    idFlux: number;
    fluxList: Flux[];
    totalResults: number,
    currentPage: number,
    isPaneOpen: boolean
}

export const flowListReducer = (state: State, action: Action) => {

    switch (action.type) {
        case "ON_LOAD_FLUX":
            return {
                ...state,
                fluxList: action.fluxList,
                totalResults: action.totalResults,
                currentPage: action.currentPage,
                loaderMode: "none"
            };
        /*  case "ON_FILTER_FLUX":
              return {...state, searchFlux: action.searchFlux};*/
        case "ON_CHANGE_SEARCH_TEXT_NAME":
            return {...state, name: action.name};
        case "ON_CHANGE_SEARCH_TEXT_TYPE":
            return {...state, type: action.typeIn};
        case "ON_CHANGE_STATUS":
            return {...state, status: action.status};
        case "ON_CHANGE_SUBMIT":
            return {...state, submit: action.submit};
        case "ON_CHANGE_DATE":
            return {...state, dateCreation: action.creationDate};
        case "ON_VALIDATION":
            return {...state, fluxList: action.fluxList, loaderMode: "none"};
        case "ON_DISPLAY_DETAIL":
            return {...state, idFlux: action.idFlux, isPaneOpen: action.isPaneOpen};
        case "ON_SEARCH":
            return {...state, loaderMode: "get"};
        case "ON_VALIDATION_CALL" :
            return {...state, loaderMode: "get"};
        default:
            return {...state};

    }
};
