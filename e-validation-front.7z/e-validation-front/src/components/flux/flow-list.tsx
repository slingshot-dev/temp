import React, {FunctionComponent, useEffect, useReducer, useState} from "react";
// @ts-ignore
import {SelectInput} from "@axa-fr/react-toolkit-form-input-select";
// @ts-ignore
import Loader from "@axa-fr/react-toolkit-loader";
// @ts-ignore
import DateInput from "@axa-fr/react-toolkit-form-input-date/dist/DateInput";
import Title from "@axa-fr/react-toolkit-title";
import Button from "@axa-fr/react-toolkit-button";
import Table, {Paging} from "@axa-fr/react-toolkit-table";
import Flux from "../../models/flux";
import FluxService from "../../api/flux.service";
import SearchFlux from "../../models/searchFlux";
import SlidingPane from "../sliding-pane/sliding-pane";
import {Link, RouteComponentProps, useHistory} from "react-router-dom";
import './flow-list.scss';
import FlowDetail from "../flux-detail/flow-detail";
import ValidationAction from "../validation-action/validation-action";
import {flowListReducer} from "./flowList.reducer";
import * as queryString from "querystring";
import RequestPage from "../../models/requestPage";
import moment from 'moment';
import Toast from "../toast";
import ErrorMessage from "../../models/errorMessage";
import errorIcon from '../../assets/svg/error.svg';
import Refresh from "../refresh";

type Props = {
    fetch?: (input: RequestInfo, init?: RequestInit) => Promise<Response>
}

type Page = {
    numberItems: number,
    page: number
}

type Params = {
    id: string
}


const FlowList: FunctionComponent<RouteComponentProps<Params> & Props> = ({match, location, fetch}) => {
    const pageParam = new RequestPage(0, 10, "", "desc");
    const workspaceId = +match.params.id;
    const initialSearchFlux = new SearchFlux("", "", "", "", "", workspaceId, pageParam);
    const search = location.search ? SearchFlux.fromJSON(queryString.parse(location.search.slice(1))) : initialSearchFlux;

    const history = useHistory();

    const [state, dispatch] = useReducer(flowListReducer, {
        name: "",
        fluxList: [],
        idFlux: 0,
        isPaneOpen: false,
        dateCreation: null,
        loaderMode: "none",
        currentPage: 1,
        totalResults: 0,
        type: "",
        status: "DEFAULT_STATUS",
        submit: "DEFAULT_SUBMIT"
    });

    const {name, fluxList, idFlux, isPaneOpen, loaderMode, currentPage, totalResults, type, dateCreation, status, submit} = state;
    const [workspaceName, setWorkspaceName] = useState("");
    const [errorMessage, setErrorMessage] = useState(new ErrorMessage(false, "", "", errorIcon))

    useEffect(() => {
            let isCancelled = false;
            if (!isCancelled) {
                getFluxByWorkspace(search);

            }
            return () => {
                isCancelled = true;
            };
        }, [workspaceId, location.search]
    );


    const getFluxByWorkspace = (searchFlux: SearchFlux) => {
        dispatch({type: "ON_SEARCH"});
        FluxService.getFluxByWorkspace(typeof (fetch) === 'undefined' ? window.fetch : fetch, searchFlux, workspaceId)
            .then(f => {
                    if (typeof (f) !== "undefined" && f.elementDTOs && f.elementDTOs[0]) {
                        setWorkspaceName(f.elementDTOs[0].workspaceName);
                    }
                    dispatch({
                        type: "ON_LOAD_FLUX",
                        fluxList: f.elementDTOs,
                        totalResults: f.numberElement,
                        currentPage: searchFlux.requestPage.page + 1
                    });
                }
            )
            .catch(error => {
                dispatch({
                    type: "ON_LOAD_FLUX",
                    fluxList: [],
                    totalResults: 0,
                    currentPage: searchFlux.requestPage.page + 1
                });

                let message = JSON.parse(error.message);
                setErrorMessage(new ErrorMessage(true, message.message.substring(0, 300) + "...", "Recherche de flux", errorIcon));
            });

    };


    const computeSortField = (s: string) => {
        if (search.requestPage.sortField === s) {
            search.requestPage.sortOrder = search.requestPage.sortOrder === 'asc' ? 'desc' : 'asc';
        } else {
            search.requestPage.sortOrder = 'desc'
        }
        search.requestPage.sortField = s;
        //dispatch({type: "ON_FILTER_FLUX", searchFlux: search});

    };

    function goToUrl() {
        getFluxByWorkspace(search);
    }

    const onSort = (s: string) => {
        computeSortField(s);
        goToUrl();
    };


    const onChangePaging = (e: Page) => {
        search.requestPage.page = e.page - 1;
        if (search.requestPage.size != e.numberItems)
            search.requestPage.page = 0;
        search.requestPage.size = e.numberItems;


        goToUrl();
        //dispatch({type: "ON_FILTER_FLUX", searchFlux: searchFlux});
        //getFluxByWorkspace(search);
    };

    const onChangeSearchText = (name: string, e: React.ChangeEvent<HTMLInputElement>) => {
        const term = e.target.value;
        if (name === "name") {
            dispatch({type: "ON_CHANGE_SEARCH_TEXT_NAME", name: term});
        }

        if (name === "type") {
            dispatch({type: "ON_CHANGE_SEARCH_TEXT_TYPE", typeIn: term});
        }

    };

    const onChangeDate = (e: any) => {
        const date = e.viewValue;

        if (!moment(date, 'DD/MM/YYYY', true).isValid() && date !== "") {
            dispatch({type: "ON_CHANGE_DATE", creationDate: date});
        } else {
            dispatch({type: "ON_CHANGE_DATE", creationDate: date});
            search.receptionDate = date;
            goToUrl();
        }


    };

    const onChangeAction = (e: any) => {
        const status = e.value;
        dispatch({type: "ON_CHANGE_STATUS", status: status});
        search.fluxStatus = status;
        goToUrl();
    };

    const onChangeSubmitAction = (e: any) => {
        const submit = e.value;
        dispatch({type: "ON_CHANGE_SUBMIT", submit: submit});
        search.fluxSubmit = submit;
        goToUrl();
    };


    const handleSearchText = (input: string, e: React.KeyboardEvent<HTMLInputElement>) => {
        const key = e.key;
        if (key === 'Enter') {
            if (input === "name") {
                console.log(`click enter on name : ${name}`);
                search.editionName = name;
            }

            if (input === "type") {
                console.log(`click enter on type : ${type}`);
                search.editionType = type;
            }
            //dispatch({type: "ON_FILTER_FLUX", searchFlux: searchFlux});
            goToUrl();

        }
    };

    const handleStartChildAction = () => {
        dispatch({type: "ON_VALIDATION_CALL"});
    };


    const handleChildAction = (idFlux: number, action: string, error: ErrorMessage) => {
        let flux: Flux = fluxList.filter(f => f.id === idFlux)[0];


        if (error.hasErrors) {
            setErrorMessage(error);
            dispatch({type: "ON_VALIDATION", fluxList: [...fluxList]})
            return;
        }

        if (action === 'SUBMIT') {
            flux = {...flux, "fluxSubmit": true};
            fluxList[fluxList.findIndex(f => f.id === idFlux)] = flux;
        } else {
            flux.fluxStatus = action;
        }

        dispatch({type: "ON_VALIDATION", fluxList: [...fluxList]})

    };

    return (
        <>
            <Loader mode={loaderMode}>
                {
                    errorMessage.hasErrors ?
                        <Toast
                            errorMessage={errorMessage}
                            position={'bottom-right'}
                            autoDelete={true}
                            dismissTime={10000}
                        />
                        : ""
                }
                <div className="af-home container">
                    <div style={{marginBottom: "&rem", marginTop: "2rem"}}>
                        <Title>{`Liste des flux du ${workspaceName}`}</Title>
                    </div>

                    <div className="float-right"><Refresh buttonAction={() => {goToUrl()}} /></div>

                    <Table className="af-table one">
                        <Table.Header>
                            <Table.Tr>
                                <Table.Th classModifier="sortable">
                  <span className="af-table__th-content">
                    <Button className="af-btn" classModifier="table-sorting" onClick={() => {
                        onSort("editionType");
                    }}
                    >
                      <span className="af-btn__text">Type d'édition</span>
                      <i
                          className={
                              "glyphicon " +
                              (search.requestPage.sortField === "editionType"
                                  ? `glyphicon-sorting-${search.requestPage.sortOrder}`
                                  : "glyphicon-sorting")
                          }
                      />

                    </Button>
                  </span>
                                </Table.Th>
                                <Table.Th classModifier="sortable">
                  <span className="af-table__th-content">
                    <Button className="af-btn" classModifier="table-sorting" onClick={() => {
                        onSort("editionName");
                    }}
                    >
                      <span className="af-btn__text">Libellé d'édition</span>
                      <i
                          className={
                              "glyphicon " +
                              (search.requestPage.sortField === "editionName"
                                  ? `glyphicon-sorting-${search.requestPage.sortOrder}`
                                  : "glyphicon-sorting")
                          }
                      />
                    </Button>
                  </span>
                                </Table.Th>
                                <Table.Th classModifier="sortable">
                  <span className="af-table__th-content">
                    <Button className="af-btn" classModifier="table-sorting" onClick={() => {
                        onSort("receptionDate");
                    }}
                    >
                      <span className="af-btn__text">Date de réception</span>
                     <i
                         className={
                             "glyphicon " +
                             (search.requestPage.sortField === "receptionDate"
                                 ? `glyphicon-sorting-${search.requestPage.sortOrder}`
                                 : "glyphicon-sorting")
                         }
                     />
                    </Button>
                  </span>
                                </Table.Th>

                                <Table.Th>Heure de réception</Table.Th>
                                <Table.Th>Consultation</Table.Th>
                                <Table.Th>Validation / Soumission</Table.Th>
                                <Table.Th classModifier="sortable">
                  <span className="af-table__th-content">
                    <Button className="af-btn" classModifier="table-sorting" onClick={() => {
                        onSort("fluxStatus");
                    }}
                    >
                      <span className="af-btn__text">Etat</span>
                      <i
                          className={
                              "glyphicon " +
                              (search.requestPage.sortField === "fluxStatus"
                                  ? `glyphicon-sorting-${search.requestPage.sortOrder}`
                                  : "glyphicon-sorting")
                          }
                      />
                    </Button>
                  </span>
                                </Table.Th>
                                <Table.Th classModifier="sortable">
                  <span className="af-table__th-content">
                    <Button className="af-btn" classModifier="table-sorting" onClick={() => {
                        onSort("fluxSubmit");
                    }}
                    >
                      <span className="af-btn__text">Traitement</span>
                      <i
                          className={
                              "glyphicon " +
                              (search.requestPage.sortField === "fluxSubmit"
                                  ? `glyphicon-sorting-${search.requestPage.sortOrder}`
                                  : "glyphicon-sorting")
                          }
                      />
                    </Button>
                  </span>
                                </Table.Th>
                            </Table.Tr>
                        </Table.Header>
                        <Table.Body>
                            <Table.Tr className="af-table-head">
                                <Table.Td>
                                    <div className="inner-addon right-addon one ">
                                        <i className="glyphicon glyphicon-search one"/>
                                        <input type="text" className="form-control one" placeholder=""
                                               onKeyDown={(e) => handleSearchText('type', e)}
                                               onChange={(e) => onChangeSearchText('type', e)}
                                        />
                                    </div>
                                </Table.Td>
                                <Table.Td>
                                    <div className="inner-addon right-addon one ">
                                        <i className="glyphicon glyphicon-search one"/>
                                        <input type="text" className="form-control one" placeholder=""
                                               onKeyDown={(e: any) => handleSearchText('name', e)}
                                               onChange={(e) => onChangeSearchText('name', e)}
                                        />
                                    </div>
                                </Table.Td>
                                <Table.Td>
                                    <div className="form-group-date">
                                        <DateInput
                                            name="dateCreation"
                                            label=""
                                            locale="fr-fr"
                                            onChange={(e: any) => {
                                                onChangeDate(e);
                                            }}
                                            viewValue={dateCreation}
                                            helpMessage=""
                                            classNameContainerLabel="col-md-1"
                                            classNameContainerInput="col-md-8"
                                            forceDisplayMessage={true}
                                            messageType="error"
                                        />
                                    </div>
                                </Table.Td>
                                <Table.Td colSpan={3}/>
                                <Table.Td>

                                    <div className="form-group-select">
                                        <SelectInput

                                            id="action"
                                            name="action"
                                            label=""
                                            onChange={(e: any) => {
                                                onChangeAction(e);
                                            }}
                                            value={status}
                                            options={[
                                                {value: "DEFAULT_STATUS", label: "- Sélectionner -"},
                                                {value: "VALIDATE", label: "Validé"},
                                                {value: "INVALIDATE", label: "Invalidé"},
                                                {value: "NEUTRAL", label: "Non qualifié"}
                                            ]}
                                        />
                                    </div>
                                </Table.Td>

                                <Table.Td>

                                    <div className="form-group-select">
                                        <SelectInput

                                            id="submitAction"
                                            name="submitAction"
                                            label=""
                                            value={submit}
                                            onChange={(e: any) => {
                                                onChangeSubmitAction(e);
                                            }}
                                            options={[
                                                {value: "DEFAULT_SUBMIT", label: "- Sélectionner -"},
                                                {value: "SUBMIT", label: "Oui"},
                                                {value: "NEUTRAL", label: "Non"}

                                            ]}
                                        />
                                    </div>
                                </Table.Td>
                            </Table.Tr>
                            {
                                fluxList.map(({id, type, name, creationDate, fluxStatus, fluxSubmit, role}) => (
                                        <Table.Tr key={id}>
                                            <Table.Td>{type}</Table.Td>
                                            <Table.Td>{name}</Table.Td>
                                            <Table.Td
                                                className={'af-table__cell af-table__cell_padding'}>{new Date(creationDate).toLocaleDateString()}</Table.Td>
                                            <Table.Td>{("0" + new Date(creationDate).getHours()).slice(-2) + ":" +
                                            ("0" + new Date(creationDate).getMinutes()).slice(-2) + ":" + ("0" + new Date(creationDate).getSeconds()).slice(-2)}</Table.Td>
                                            <Table.Td>
                                                <Link className="af-btn--circle" title="Ouvrir" role="button"
                                                      to={{
                                                          pathname: "/open/" + id,
                                                          state: {
                                                              'name': name
                                                          }
                                                      }}>
                                                    <i className="glyphicon glyphicon-folder-open"/>
                                                </Link>


                                                <a className="af-btn--circle" title="Détails" role="button"
                                                   onClick={() => {
                                                       dispatch({type: "ON_DISPLAY_DETAIL", idFlux: id, isPaneOpen: true})
                                                   }}
                                                >
                                                    <i className="glyphicon glyphicon-info-sign"/>
                                                </a>
                                            </Table.Td>
                                            <Table.Td>
                                                <ValidationAction idFlux={id} action={fluxStatus} submitAction={fluxSubmit ? "SUBMIT" : ""}
                                                                  childAction={handleChildAction}
                                                                  handleStartChildAction={handleStartChildAction} role={role}/>
                                            </Table.Td>
                                            <Table.Td>
                                                <div
                                                    className={fluxStatus === "VALIDATE" ? "oval-valide" : fluxStatus === "INVALIDATE" ? "oval-invalide" : "oval-other"}>
                                                    {fluxStatus === "VALIDATE" ? "Validé" : fluxStatus === "INVALIDATE" ? "Invalidé" : "Non qualifié"}
                                                </div>
                                            </Table.Td>
                                            <Table.Td>
                                                <div
                                                    className={fluxSubmit ? "oval-oui" : "oval-other"}>
                                                    {fluxSubmit ? "Oui" : "Non"}
                                                </div>
                                            </Table.Td>
                                        </Table.Tr>
                                    )
                                )}
                        </Table.Body>

                    </Table>
                    <Paging
                        onChange={(e: any) => onChangePaging(e)}
                        numberItems={search.requestPage.size}
                        numberPages={Math.ceil(totalResults / search.requestPage.size)}
                        currentPage={currentPage}
                    />

                    <SlidingPane
                        className="some-custom-class"
                        overlayClassName="none"
                        isOpen={isPaneOpen}
                        title="Détails du flux"
                        subtitle={name}

                        onRequestClose={() => {
                            // triggered on "<" on left top click or on outside click
                            dispatch({type: "ON_DISPLAY_DETAIL", idFlux: 0, isPaneOpen: false})
                        }}
                    >
                        <dl className="information-list">
                            <FlowDetail idFlux={idFlux} isPaneOpen={isPaneOpen}/>
                        </dl>
                    </SlidingPane>

                </div>
            </Loader>
        </>
    );
};
//
// const enhanceAuth = compose<Props, Props>(
//     withAuthentication(fetch)
// );
//
// //const FlowListEnhance = enhanceAuth(FlowList);


export default FlowList;
