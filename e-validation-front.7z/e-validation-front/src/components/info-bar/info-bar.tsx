import React, {FunctionComponent} from "react";

import "./info-bar.scss";

const InfoBar : FunctionComponent = () => (
  <div className="af-home container" data-label="DP_fluxPanel">
    <div id="u17_state0" className="panel_state" data-label="State2">
      <div id="u17_state0_content" className="panel_state_content">
        <div
          id="u18"
          className="ax_default"
          data-left="0"
          data-top="0"
          data-width="772"
          data-height="46"
        >
          <div id="u19" className="ax_default box_1">
            <div id="u19_div" className=""></div>
            <div
              id="u19_text"
              className="text "
              style={{ top: "14px", transformOrigin: "315.5px 8.5px" }}
            >
              <p>
                <span>
                  Pour afficher la liste des flux sélectionnez un workspace
                </span>
              </p>
            </div>
          </div>

          <div
            id="u20"
            className="ax_default"
            data-left="0"
            data-top="0"
            data-width="82"
            data-height="46"
          >
            <div id="u21" className="ax_default icon">
              <img
                alt=""
                id="u21_img"
                className="img "
                src="assets/images/arrow_blue_light.png"
              ></img>
            </div>

            <div id="u22" className="ax_default label">
              <div id="u22_div" className=""></div>
              <div id="u22_text" className="text ">
                <p>
                  <span>i</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default InfoBar;
