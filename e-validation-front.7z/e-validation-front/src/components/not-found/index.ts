export { default } from './not-found';
