import Document from "../../models/document";

type Action =
    | { type: 'ON_LOAD_DOCUMENTS', documentList: Document[], totalResults: number, fluxName: string, workspaceId: number, currentPage: number }
    | { type: 'ON_CHANGE_SEARCH_TEXT_NAME', name: string }
    | { type: 'ON_DISPLAY_DETAIL', idDocument: number, isPaneOpen: boolean }
    | { type: 'ON_SEARCH' };


interface State {
    loaderMode: string;
    idDocument: number;
    fluxName: string;
    workspaceId: number;
    name: string;
    documentList: Document[];
    totalResults: number;
    currentPage: number;
    isPaneOpen: boolean
}


export const documentsReducer = (state: State, action: Action) => {

    switch (action.type) {
        case "ON_LOAD_DOCUMENTS":
            return {
                ...state, documentList: action.documentList, totalResults: action.totalResults, currentPage: action.currentPage,
                fluxName: action.fluxName, workspaceId: action.workspaceId, loaderMode: "none"
            };
        case "ON_CHANGE_SEARCH_TEXT_NAME":
            return {...state, name: action.name};
        case "ON_DISPLAY_DETAIL":
            return {...state, idDocument: action.idDocument, isPaneOpen: action.isPaneOpen};
        case "ON_SEARCH":
            return {...state, loaderMode: "get"};
        default:
            return {...state};

    }
};
