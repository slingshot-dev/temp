import React, {createContext, FunctionComponent, useContext, useEffect, useState} from "react";
// @ts-ignore
import {Loader} from "@axa-fr/react-toolkit-all";
// @ts-ignore
import {AuthenticationContext} from '@axa-fr/react-oidc-context';
import {compose} from "recompose";
// @ts-ignore
import {withAuthentication} from '@axa-fr/react-oidc-context-fetch';
import UserInfo from "../../models/userInfo";
import UserService from "../../api/user.service";
import {IFetch} from "../workspaces/workspaces";

export const UserContext = createContext<UserInfo>(new UserInfo(0, "", []));

const UserContextProvider: FunctionComponent<IFetch> = (prop) => {
    const [user, setUser] = useState<UserInfo>(new UserInfo(-1, "", []));
    const [loading, setLoading] = useState<string>("get");
    const authenticationContext = useContext<any>(AuthenticationContext);
    let userId = -1;
    useEffect(() => {
        let isCancelled = false;

        if (authenticationContext && authenticationContext.oidcUser && authenticationContext.oidcUser.profile) {
            UserService.getUserByMail(typeof (prop.fetch) === 'undefined' ? fetch : prop.fetch).then(usr => {
                if (!isCancelled) {
                    userId = usr.id;
                    setUser(usr);
                    setLoading("none");
                }
            });
        }

        return () => {
            isCancelled = true;
        };

    }, [userId]);

    return (
        <>
            <Loader loading={loading}>
                <UserContext.Provider value={user}>
                    {prop.children}
                </UserContext.Provider>
            </Loader>

        </>
    );
};

const enhanceAuth = compose<IFetch, {}>(
    withAuthentication(fetch)
);

const UserContexProviderAuth = enhanceAuth(UserContextProvider);


export default UserContexProviderAuth;
