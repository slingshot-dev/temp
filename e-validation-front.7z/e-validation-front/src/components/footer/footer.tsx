import React from 'react';
import logo from '@axa-fr/react-toolkit-core/dist/assets/logo-axa.svg';
// @ts-ignore
import { Footer } from '@axa-fr/react-toolkit-all';
import './footer.scss';
const FooterApp = () => {
  return <Footer icon={logo} />;
};

export default FooterApp;
