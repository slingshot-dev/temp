export { default } from './footer';
