export { default } from './sliding-pane';
