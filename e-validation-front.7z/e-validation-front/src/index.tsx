
import React from 'react';
import ReactDOM from 'react-dom';

import './index.css';
import App from "./app";

require ('moment/locale/fr.js');

ReactDOM.render(<App />, document.getElementById('root'));

