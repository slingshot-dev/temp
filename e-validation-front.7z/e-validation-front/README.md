Ce projet présente la partie client e-validation qui est développée en REACT

## Installation du projet en Local

Afin de lancer la partie client en local, vous devez suivre les étapes suivantes:

### Installation du NPM

Installer la [dernière version NPM](https://docs.npmjs.com/)

### Clonage du projet 

Afin de cloner le repo en local, lancer la commande suivante : 

git clone https://XXX@axafrance.visualstudio.com/DefaultCollection/PFEL/_git/e-validation

XXX : Votre token généré sur AZURE

### Installation des modules nécessaires : 

Le projet contient les modules classiques NODE et intègre aussi le Toolkit d'AXA qui englobe tous les composants graphiques nécessaire : 

Pour installer les modules : 

1 - Se positionner sous la racine du projet : $ cd e-validation/client/

2 - Installer les modules NODE : $ npm install

3 - Vérifier si le dossier @axa-fr contenant le toolkit-all AXA est installé dans node_modules, sinon vous pouvez l'installer via la commande suivante :

   npm install @axa-fr/react-toolkit-all

4 - Installer node-sass : $ npm install node-sass

### Exécution du projet :

Pour exécuter le projet, lancez la commande suivante : $ npm start